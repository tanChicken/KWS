---
name: Timeless Heritage
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#424844'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#727973'
  outline-variant: '#c2c8c2'
  surface-tint: '#496455'
  primary: '#173124'
  on-primary: '#ffffff'
  primary-container: '#2d4739'
  on-primary-container: '#98b5a3'
  inverse-primary: '#b0cdbb'
  secondary: '#755a2c'
  on-secondary: '#ffffff'
  secondary-container: '#fdd79f'
  on-secondary-container: '#785c2f'
  tertiary: '#2b2c29'
  on-tertiary: '#ffffff'
  tertiary-container: '#41423f'
  on-tertiary-container: '#afaeaa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ccead6'
  primary-fixed-dim: '#b0cdbb'
  on-primary-fixed: '#062014'
  on-primary-fixed-variant: '#324c3e'
  secondary-fixed: '#ffdead'
  secondary-fixed-dim: '#e5c18a'
  on-secondary-fixed: '#281900'
  on-secondary-fixed-variant: '#5b4217'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 80px
  max-width: 1280px
---

## Brand & Style
This design system embodies a sophisticated, high-end travel and lifestyle aesthetic. It draws inspiration from traditional craftsmanship and the serenity of nature, specifically referencing the deep greens of Korean forests and the muted elegance of prestige metalwork. 

The visual style is **Minimalist / Corporate Modern** with an emphasis on high-quality editorial layouts. It evokes feelings of exclusivity, meticulous curation, and historical depth. Whitespace is used as a luxury element, allowing the rich primary colors and elegant typography to breathe. The interface should feel established and trustworthy, yet contemporary and light.

## Colors
The palette is centered around a "Deep Forest" primary green, which provides a grounding, authoritative presence. This is complemented by "Muted Gold," used sparingly for accents, icons, and CTA focus states to suggest prestige.

The UI relies heavily on a warm, off-white surface (`#F9F7F2`) to avoid the clinical feel of pure white, creating a more welcoming, parchment-like experience. Secondary text and borders utilize a deep neutral charcoal to ensure legibility while maintaining the high-contrast sophistication of the brand.

## Typography
The typography system uses a classic serif/sans-serif pairing to balance heritage with modern utility. **Playfair Display** is reserved for headlines and editorial callouts, providing a sense of literary luxury. 

**Manrope** serves as the functional workhorse for body copy and UI labels, chosen for its clean, geometric clarity that keeps the interface feeling modern and accessible. Special attention is paid to "Label Caps" for sub-headers and metadata, utilizing wide tracking to mimic premium archival labeling.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain an editorial, magazine-like feel. Content is centered within a 1280px container to ensure high-resolution displays don't result in overly long line lengths for reading.

A 12-column grid is used for desktop, transitioning to a 4-column grid for mobile. Spacing is generous, utilizing an 8px base unit. Section-level vertical padding should be substantial (80px–120px) to reinforce the "luxury of space" inherent in the brand style.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** rather than heavy shadows. Surfaces are differentiated by subtle shifts between the off-white background and slightly lighter or darker container fills.

Where elevation is required (e.g., modals or primary floating actions), use **Ambient Shadows**: extremely soft, long-range blurs (20px-40px) with very low opacity (5-8%) tinted with the primary forest green. This keeps the shadows feeling "organic" and integrated into the environment rather than artificial.

## Shapes
The design system utilizes **Soft** roundedness. While the brand is traditional, sharp corners can feel too aggressive. A 0.25rem (4px) radius on standard components provides a subtle "human touch" while maintaining the structural integrity and precision of a prestige brand. Larger containers like cards may scale up to 0.5rem (8px) to feel more approachable.

## Components
- **Buttons**: Primary buttons are filled with the Forest Green, using white Manrope text in semi-bold. Secondary buttons use a fine 1px border in Forest Green or Gold with no fill.
- **Input Fields**: Minimalist design with only a bottom border or a very light-tinted background. Focus states use the Muted Gold for the border color.
- **Cards**: Use a subtle border (1px, 10% opacity Forest Green) rather than a shadow. Ensure generous internal padding (min 24px).
- **Chips/Badges**: Use the warm beige background with Forest Green text for a subtle, integrated look.
- **Lists**: Separated by thin, horizontal rules (1px) in a light neutral tint, emphasizing the verticality of the layout.
- **Icons**: Use thin-stroke, linear icons. When possible, icons should be rendered in the Muted Gold to act as "jeweled" accents within the interface.